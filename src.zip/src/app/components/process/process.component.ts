import { ChangeDetectionStrategy, Component } from '@angular/core';
import { NgFor, NgIf } from '@angular/common';

interface SchoolContentItem {
  readonly eyebrow: string;
  readonly title: string;
  readonly text: string;
  readonly icon: 'people' | 'movement' | 'sparkles';
}

interface ProcessStep {
  readonly title: string;
  readonly text: string;
}

interface JourneyPair {
  readonly item: SchoolContentItem;
  readonly step: ProcessStep;
}

@Component({
  selector: 'app-process',
  standalone: true,
  imports: [NgFor, NgIf],
  templateUrl: './process.component.html',
  styleUrl: './process.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProcessComponent {
  readonly schoolItems: readonly SchoolContentItem[] = [
    {
      eyebrow: 'Acompañamiento',
      title: 'Profesionales que suman',
      text: 'Contenido con profesionales en distintos ámbitos del Bienestar y la Salud Integral.',
      icon: 'people'
    },
    {
      eyebrow: 'Práctica flexible',
      title: 'Clases para cada momento',
      text: 'Clases de distintos estilos, intensidades y duraciones.',
      icon: 'movement'
    },
    {
      eyebrow: 'Una escuela viva',
      title: 'Nuevos contenidos',
      text: 'Nuevos contenidos semanales sin publicidad.',
      icon: 'sparkles'
    }
  ];

  readonly steps: readonly ProcessStep[] = [
    {
      title: 'Envía tus datos',
      text: 'Solo tienes que enviar tu nombre y dirección de correo electrónico en el formulario que se despliega al darle al botón de Quiero Inscribirme.'
    },
    {
      title: 'Nos pondremos en contacto contigo',
      text: 'En los días posteriores, nos pondremos en contacto contigo a través del contacto que hayas facilitado, para conocernos mejor.'
    },
    {
      title: 'Vemos si es tu momento',
      text: 'Veremos si es tu momento para comenzar esta aventura. Las plazas son limitadas.'
    }
  ];


  readonly journeyPairs: readonly JourneyPair[] = this.schoolItems.map((item, index) => ({
    item,
    step: this.steps[index] ?? this.steps[this.steps.length - 1]!
  }));

}
